# Rubber Succubus — Standalone Deployment Guide

This is a fully independent static website. You can host it anywhere without any dependency on Manus.

---

## What's Included

- **Complete React app** compiled to static HTML/CSS/JS
- **All pages**: Home, Services, Gallery, FAQ, Events, Connect, Checkout
- **All features**: Age gate, animations, forms, social links, integrations
- **CNAME file** for custom domain pointing

---

## Quick Start: GitHub Pages (Recommended)

### 1. Create a new GitHub repository
```bash
cd standalone-export
git init
git add .
git commit -m "Initial commit: Rubber Succubus website"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/rubber-succubus.git
git push -u origin main
```

### 2. Enable GitHub Pages
- Go to your repo → **Settings** → **Pages**
- Source: **Deploy from a branch**
- Branch: **main** | Folder: **/ (root)**
- Click **Save**

### 3. Point your domain
- Go to your domain registrar (GoDaddy, Namecheap, etc.)
- Add a **CNAME record**:
  - Name: `@` or leave blank
  - Value: `YOUR_USERNAME.github.io`
- Wait 5-30 minutes for DNS to propagate

Your site will be live at `rubbersuccubus.com`!

---

## Alternative Hosting Options

### Netlify (Even Easier)
1. Drag and drop the `standalone-export` folder into [netlify.com/drop](https://netlify.com/drop)
2. Connect your domain in Netlify settings
3. Done!

### Vercel
1. Push to GitHub
2. Import repo at [vercel.com](https://vercel.com)
3. Vercel auto-deploys on every push
4. Connect domain in project settings

### Your Own Server (Apache/Nginx)
1. Upload all files to your web server
2. Configure your domain DNS to point to your server IP
3. Serve the files as static content

---

## Updating the Site

### To add/edit content:

1. **Edit the source files** in `/client/src/pages/`:
   - `Home.tsx` — landing page
   - `Services.tsx` — service offerings
   - `Gallery.tsx` — portfolio images
   - `FAQ.tsx` — frequently asked questions
   - `Events.tsx` — calendar & events
   - `Connect.tsx` — contact form & socials
   - `Checkout.tsx` — booking/payment

2. **Add your real credentials** (one-time setup):

   **Connect.tsx:**
   - `FORMSPREE_FORM_ID` → get from [formspree.io](https://formspree.io)
   - `MAILCHIMP_ACTION_URL` → get from Mailchimp
   - Replace placeholder social URLs with your real links

   **Checkout.tsx:**
   - `STRIPE_PAYMENT_LINKS` → create at [dashboard.stripe.com/payment-links](https://dashboard.stripe.com/payment-links)

   **Events.tsx:**
   - `GOOGLE_CALENDAR_EMBED_SRC` → get from [calendar.google.com](https://calendar.google.com) (Settings → Integrate calendar)

   **index.html:**
   - Uncomment Google Analytics block
   - Replace `G-XXXXXXXXXX` with your real Measurement ID from [analytics.google.com](https://analytics.google.com)

3. **Rebuild the site**:
   ```bash
   cd /path/to/rubber-succubus
   pnpm build
   ```

4. **Copy new files to deployment**:
   ```bash
   rm -rf standalone-export/*
   cp -r dist/public/* standalone-export/
   echo "rubbersuccubus.com" > standalone-export/CNAME
   ```

5. **Push to GitHub/Netlify/Vercel** — it auto-deploys!

---

## File Structure

```
standalone-export/
├── index.html              ← Main page (all routes handled here)
├── CNAME                   ← Domain configuration for GitHub Pages
├── assets/
│   ├── index-XXXXX.js      ← Compiled React app
│   └── index-XXXXX.css     ← All styles (Tailwind + custom)
└── __manus__/              ← Manus metadata (safe to delete)
```

---

## Customization

### Colors & Fonts
Edit `client/src/index.css` for the dark luxury theme:
- Background: `#080808` (black)
- Text: `#F5F1E8` (cream)
- Accent: `#B71C1C` (red-700)
- Fonts: Cormorant Garamond (serif), Jost (body)

### Add Images
1. Upload images to a CDN or S3
2. Replace image URLs in the page components
3. Rebuild and redeploy

### Add Pages
1. Create a new file in `client/src/pages/NewPage.tsx`
2. Add the route in `client/src/App.tsx`
3. Add nav link in `client/src/pages/Home.tsx`
4. Rebuild

---

## Troubleshooting

**Site shows 404 errors on subpages?**
- Make sure your host serves `index.html` for all routes (SPA routing)
- GitHub Pages and Netlify do this automatically
- For custom servers, configure your web server to rewrite all requests to `index.html`

**Domain not working?**
- Wait 5-30 minutes for DNS to propagate
- Check your domain registrar's DNS settings
- Verify the CNAME record is correct

**Forms not working?**
- Make sure you've added your real Formspree ID and Mailchimp URL
- Test at [formspree.io](https://formspree.io) first

---

## Support

This is a fully static site — no backend, no servers to manage. If you need help:
- **GitHub Pages issues**: [docs.github.com/pages](https://docs.github.com/pages)
- **Netlify issues**: [netlify.com/support](https://netlify.com/support)
- **Stripe issues**: [stripe.com/docs](https://stripe.com/docs)
- **Formspree issues**: [formspree.io/help](https://formspree.io/help)

You're completely independent now. Enjoy!
