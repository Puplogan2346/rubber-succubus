#!/bin/bash
# Rubber Succubus — Quick Setup Script for GitHub Pages
# This script initializes your standalone site for GitHub Pages deployment

set -e

echo "🎭 Rubber Succubus — GitHub Pages Setup"
echo "========================================"
echo ""

# Check if git is initialized
if [ ! -d ".git" ]; then
    echo "📦 Initializing git repository..."
    git init
    git config user.email "rubbersuccubusbiz@gmail.com"
    git config user.name "Rubber Succubus"
else
    echo "✓ Git repository already initialized"
fi

echo ""
echo "📝 Adding files to git..."
git add .
git commit -m "Initial commit: Rubber Succubus website with all features" || echo "✓ Files already committed"

echo ""
echo "🌿 Setting up main branch..."
git branch -M main 2>/dev/null || echo "✓ Already on main branch"

echo ""
echo "🔗 Next steps:"
echo "1. Create a new repository at https://github.com/new"
echo "2. Name it: rubber-succubus"
echo "3. Make it PRIVATE (recommended)"
echo "4. Run these commands:"
echo ""
echo "   git remote add origin https://github.com/YOUR_USERNAME/rubber-succubus.git"
echo "   git push -u origin main"
echo ""
echo "5. Go to Settings → Pages"
echo "6. Set Source to: Deploy from a branch"
echo "7. Select Branch: main | Folder: / (root)"
echo "8. Click Save"
echo ""
echo "9. Point your domain at GitHub Pages:"
echo "   - Add CNAME record: @ → YOUR_USERNAME.github.io"
echo "   - Or use GitHub's custom domain feature"
echo ""
echo "✅ Your site will be live in 5-30 minutes!"
echo ""
